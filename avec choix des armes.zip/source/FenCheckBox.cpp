#include "FenCheckBox.h"

FenCheckBox::FenCheckBox()
{
}
