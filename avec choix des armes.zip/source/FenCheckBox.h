#ifndef FENCHECKBOX_H
    #define FENCHECKBOX_H

    #include "ClassePourPersonnage.h"
    #include <QtGui>

    class FenCheckBox
    {
    public:
        FenCheckBox();
    };

#endif // FENCHECKBOX_H
