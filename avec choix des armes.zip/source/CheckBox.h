/*
	Copyright (C) 2011 Florent FAYOLLAS

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#ifndef CHECK_BOX_H
	#define CHECK_BOX_H

	#include <QCheckBox>
	#include "ClassePourPersonnage.h"

	class CheckBox : public QCheckBox
	{
		Q_OBJECT
	public:
		CheckBox(Vetement *vet, QLabel* label, QLabel* bonus, QLabel* malus);
		CheckBox(Protection *pr, QLabel* label, QLabel* bonus, QLabel* malus, QLabel* nombrePr);
		CheckBox(Arme *arme, QLabel* label, QLabel* bonus, QLabel* malus, QLabel* DEGATS);
		CheckBox(Fleche *fleche, QLabel* label, QLineEdit* nombre, QLabel* bonus,
				 QPushButton *plus, QPushButton *moins);
		CheckBox(QString *equipement, QLabel* label);

		~CheckBox();

	public slots:
		void changerVet(int etat);
		void changerPr(int etat);
		void changerArme(int etat);
		void changerFleche(int etat);
		void changerEquipement(int etat);

		void fleche_plus();
		void fleche_moins();

	signals:
		void bonus_malus_change();

	private:
		// Tableaux
		static QVector<Arme*> ALL_armes;
		static QVector<Protection*> ALL_pr;
		static QVector<Vetement*> ALL_vets;
		static QVector<Fleche*> ALL_fleches;
		static QVector<QString> ALL_equipements;

		// Objets
		Vetement* m_vet;
		Protection* m_pr;
		Arme* m_arme;
		Fleche* m_fleche;
		QString* m_equipement;

		// Label
		QLabel* m_label;
		QLabel* m_bonus;
		QLabel* m_malus;
		QLabel* m_pr_nombreLabel;
		QLabel* m_degats;
		QLineEdit* m_nombre;

		// Boutons
		QPushButton *m_plus;
		QPushButton *m_moins;
	};

#endif // CHECK_BOX_H
