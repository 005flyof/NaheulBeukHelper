/*
	Copyright (C) 2011 Florent FAYOLLAS

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License along
	with this program; if not, write to the Free Software Foundation, Inc.,
	51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#ifndef ORIGINE_H
	#define ORIGINE_H

	#include <QtGui>
	#include "Caracteristiques.h"

	class Origine
	{
	public:
		Origine(QString nom = "Origine sans nom !", int EV = 0, int AT = 0,
				int cou = 0, int intel = 0, int cha = 0, int ad = 0, int fo = 0,
				int COU = 0, int INTEL = 0, int CHA = 0, int AD = 0, int FO = 0);

		void setCarac_mini(int COU_recup, int INT_recup, int CHA_recup, int AD_recup, int FO_recup);
		void setCarac_max(int COU_recup, int INT_recup, int CHA_recup, int AD_recup, int FO_recup);

		QString getNom() const;
		int getEV() const;
		Caracteristiques getMini() const;
		Caracteristiques getMaxi() const;
		int getAT() const;

	private:
		QString m_nomOrigine;
		Caracteristiques m_caracMini;
		Caracteristiques m_caracMax;
		int m_EV;
		int m_AT;
	};

#endif // ORIGINE_H
