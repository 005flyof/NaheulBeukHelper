/*
    Copyright (C) 2011 Florent FAYOLLAS

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "CheckBox.h"
#include <QtGui>
#include "Personnage.h"
#include "ClassePourPersonnage.h"
#include <stdio.h>
#include <stdlib.h>

CheckBox::CheckBox(Vetement* vet, QLabel* label, QLabel* bonus, QLabel* malus)
    : QCheckBox(), m_vet(vet), m_label(label), m_bonus(bonus), m_malus(malus)
{
    // Objets
    m_pr = 0;
    m_arme = 0;
    m_fleche = 0;
    m_equipement = 0;

    // Boutons
    m_plus = 0;
    m_moins = 0;

    // Label
    m_nombre = 0;
    m_pr_nombreLabel = 0;
    m_degats = 0;
}
CheckBox::CheckBox(Protection *pr, QLabel* label, QLabel* bonus, QLabel* malus, QLabel* nombrePr)
    : QCheckBox(), m_pr(pr), m_label(label), m_bonus(bonus), m_malus(malus), m_pr_nombreLabel(nombrePr)
{
    // Objets
    m_vet = 0;
    m_arme = 0;
    m_fleche = 0;
    m_equipement = 0;

    // Boutons
    m_plus = 0;
    m_moins = 0;

    // Label
    m_nombre = 0;
    m_degats = 0;
}
CheckBox::CheckBox(Arme *arme, QLabel* label, QLabel* bonus, QLabel* malus, QLabel* DEGATS)
    : QCheckBox(), m_arme(arme), m_label(label), m_bonus(bonus), m_malus(malus), m_degats(DEGATS)
{	// Objets
    m_vet = 0;
    m_pr = 0;
    m_fleche = 0;
    m_equipement = 0;

    // Boutons
    m_plus = 0;
    m_moins = 0;

    // Label
    m_nombre = 0;
    m_pr_nombreLabel = 0;
}
CheckBox::CheckBox(Fleche *fleche, QLabel* label, QLineEdit* nombre, QLabel* bonus,
                   QPushButton *plus, QPushButton *moins)
    : QCheckBox(), m_fleche(fleche), m_label(label), m_bonus(bonus),
      m_nombre(nombre), m_plus(plus), m_moins(moins)
{
    // Objets
    m_vet = 0;
    m_pr = 0;
    m_arme = 0;
    m_equipement = 0;

    // Label
    m_malus = 0;
    m_pr_nombreLabel = 0;
    m_degats = 0;

    QObject::connect(m_plus, SIGNAL(clicked()), this, SLOT(fleche_plus()));
    QObject::connect(m_moins, SIGNAL(clicked()), this, SLOT(fleche_moins()));
}
CheckBox::CheckBox(QString *equipement, QLabel* label)
    : QCheckBox(), m_equipement(equipement), m_label(label)
{
    // Objets
    m_vet = 0;
    m_pr = 0;
    m_arme = 0;
    m_fleche = 0;

    // Boutons
    m_plus = 0;
    m_moins = 0;

    // Label
    m_bonus = 0;
    m_malus = 0;
    m_nombre = 0;
    m_pr_nombreLabel = 0;
    m_degats = 0;
}

CheckBox::~CheckBox()
{
}


void CheckBox::changerVet(int etat)
{
    if (etat == Qt::Checked)
    {
        QStringList vets;

        for (int lecteur = 0; lecteur < ALL_vets.size(); lecteur++)
        {
            vets << ALL_vets.at(lecteur)->getNom();
        }

        bool ok(false);
        QString nomVet = QInputDialog::getItem(this, "Choix du v�tement",
                                                "Veuillez choisir un v�tement :", vets, 0, false, &ok);
        if (ok && !nomVet.isEmpty())
        {
            for (int lecteur = 0; lecteur < ALL_vets.size(); lecteur++)
            {
                if (ALL_vets.at(lecteur)->getNom() == nomVet)
                {
                    *m_vet = ALL_vets.at(lecteur);

                // On affiche ce que l'on a fait
                    m_label->setText(m_vet->getNom());
                    m_bonus->setText(m_vet->getBonus());
                    m_malus->setText(m_vet->getMalus());
                    emit bonus_malus_change();
                }
            }
        }
        else
            this->setChecked(false);
    }
    else
    {
        m_vet->setNom(PAS_VETEMENT);
        m_vet->setBonus(0, 0, 0, 0, 0);
        m_vet->setMalus(0, 0, 0, 0, 0);

        m_label->setText(m_vet->getNom());
        m_bonus->setText("-");
        m_malus->setText("-");

        emit bonus_malus_change();
    }
}
void CheckBox::changerPr(int etat)
{
    if (etat == Qt::Checked)
    {
        QStringList pr;

        for (int lecteur = 0; lecteur < ALL_pr.size(); lecteur++)
        {
            pr << ALL_pr.at(lecteur)->getNom();
        }

        bool ok(false);
        QString nomPr = QInputDialog::getItem(this, "Choix de la protection",
                                                "Veuillez choisir une protection :", pr, 0, false, &ok);
        if (ok && !nomPr.isEmpty())
        {
            for (int lecteur = 0; lecteur < ALL_pr.size(); lecteur++)
            {
                if (ALL_pr.at(lecteur)->getNom() == nomPr)
                {
                    *m_pr = ALL_pr.at(lecteur);

                // On affiche ce que l'on a fait
                    m_label->setText(m_pr->getNom());
                    m_pr_nombreLabel->setText(m_pr->getNombrePR());
                    m_bonus->setText(m_pr->getBonus());
                    m_malus->setText(m_pr->getMalus());
                    emit bonus_malus_change();
                }
            }
        }
        else
            this->setChecked(false);
    }
    else
    {
        m_pr->setNom(PAS_PROTECTION);
        m_pr->setPr(0);
        m_pr->setBonus(0, 0, 0, 0, 0, 0, 0);
        m_pr->setMalus(0, 0, 0, 0, 0, 0, 0);

        m_label->setText(m_pr->getNom());
        m_pr_nombreLabel->setText("-");
        m_bonus->setText("-");
        m_malus->setText("-");

        emit bonus_malus_change();
    }
}
void CheckBox::changerArme(int etat)
{
    if (etat == Qt::Checked)
    {
        QStringList armes;

        for (int lecteur = 0; lecteur < ALL_armes.size(); lecteur++)
        {
            armes << ALL_armes.at(lecteur)->getNom();
        }

        bool ok(false);
        QString nomArme = QInputDialog::getItem(this, "Choix de l'arme",
                                                "Veuillez choisir une arme :", armes, 0, false, &ok);
        if (ok && !nomArme.isEmpty())
        {
            for (int lecteur = 0; lecteur < ALL_armes.size(); lecteur++)
            {
                if (ALL_armes.at(lecteur)->getNom() == nomArme)
                {
                    *m_arme = ALL_armes.at(lecteur);

                // On affiche ce que l'on a fait
                    m_label->setText(m_arme->getNom());
                    m_degats->setText(m_arme->getDegats());
                    m_bonus->setText(m_arme->getBonus());
                    m_malus->setText(m_arme->getMalus());
                    emit bonus_malus_change();
                }
            }
        }
        else
            this->setChecked(false);
    }
    else
    {
        m_arme->setNom(PAS_ARME);
        m_arme->setDegats(0, 0);
        m_arme->setBonus(0, 0, 0, 0, 0, 0, 0);
        m_arme->setMalus(0, 0, 0, 0, 0, 0, 0);

        m_label->setText(m_arme->getNom());
        m_degats->setText("-");
        m_bonus->setText("-");
        m_malus->setText("-");

        emit bonus_malus_change();
    }
}
void CheckBox::changerFleche(int etat)
{
    if (etat == Qt::Checked)
    {
        QStringList fleche;

        for (int lecteur = 0; lecteur < ALL_fleches.size(); lecteur++)
        {
            fleche << ALL_fleches.at(lecteur)->getNom();
        }

        bool ok(false);
        QString nomFleche = QInputDialog::getItem(this, "Choix de fl�che",
                                                "Veuillez choisir un type de fl�che :", fleche, 0, false, &ok);

        if (ok && !nomFleche.isEmpty())
        {
            int nbFleche = QInputDialog::getInt(this, "Choix du nombre de fl�ches",
                                                    "S�lectionner le nombre de fl�ches :", 0, 0, 100, 1, &ok);
            if (ok)
            {
                for (int lecteur = 0; lecteur < ALL_fleches.size(); lecteur++)
                {
                    if (ALL_fleches.at(lecteur)->getNom() == nomFleche)
                    {
                        *m_fleche = ALL_fleches.at(lecteur);
                        m_fleche->setNombre(nbFleche);
                        m_plus->setEnabled(true);
                        m_moins->setEnabled(true);

                    // On affiche ce que l'on a fait
                        m_label->setText(m_fleche->getNom());
                        m_nombre->setText(QString::number(m_fleche->getNombre()));
                            m_nombre->setEnabled(true);
                        m_bonus->setText(m_fleche->getBonus());
                        emit bonus_malus_change();
                    }
                }
            }
        }
        else
        {
            this->setChecked(false);
            m_plus->setEnabled(false);
            m_moins->setEnabled(false);
        }
    }
    else
    {
        m_fleche->setNom(PAS_FLECHE);
        m_fleche->setNombre(0);
        m_fleche->setDegats(0);
        m_fleche->setBonus(0);

        m_label->setText(m_fleche->getNom());
        m_nombre->setText(QString::number(m_fleche->getNombre()));
            m_nombre->setEnabled(false);
        m_bonus->setText("-");

        m_plus->setEnabled(false);
        m_moins->setEnabled(false);
    }
}
void CheckBox::changerEquipement(int etat)
{
    if (etat == Qt::Checked)
    {
        QStringList nom;

        for (int lecteur = 0; lecteur < ALL_equipements.size(); lecteur++)
        {
            nom << ALL_equipements.at(lecteur);
        }

        bool ok(false);
        QString nomE = QInputDialog::getItem(this, "Choix de l'�quipement",
                                                "Veuillez choisir un �quipement :", nom, 0, false, &ok);
        if (ok && !nomE.isEmpty())
        {
            for (int lecteur = 0; lecteur < ALL_equipements.size(); lecteur++)
            {
                if (ALL_equipements.at(lecteur) == nomE)
                {
                    *m_equipement = ALL_equipements.at(lecteur);

                // On affiche ce que l'on a fait
                    m_label->setText(*m_equipement);
                    emit bonus_malus_change();
                }
            }
        }
        else
            this->setChecked(false);
    }
    else
    {
        *m_equipement = PAS_EQUIPEMENTS;
        m_label->setText(*m_equipement);
    }
}


void CheckBox::fleche_plus()
{
    m_fleche->setNombre(m_fleche->getNombre() + 1);
    m_nombre->setText(QString::number(m_fleche->getNombre()));
}
void CheckBox::fleche_moins()
{
    m_fleche->setNombre(m_fleche->getNombre() - 1);
    m_nombre->setText(QString::number(m_fleche->getNombre()));
}


// Variables statiques
QVector<Vetement*> ouvrirVet()
{
    QVector<Vetement*> vetT;

    // V�tements
    QFile vet("prog-data/vet");

    if (!vet.open(QIODevice::ReadOnly | QIODevice::Text))
        fatalError("Impossible d'ouvrir le fichier contenant les v�tements !");

    QTextStream entree(&vet);
    entree.setDevice(&vet);

    QString ligne = entree.readLine();

    while (ligne == "~!vetement!~")
    {
        int ouverture_COU(0), ouverture_INT(0), ouverture_CHA(0), ouverture_AD(0), ouverture_FO(0),
                ouverture_AT(0), ouverture_PRD(0);
        int ouverture_cou(0), ouverture_int(0), ouverture_cha(0), ouverture_ad(0), ouverture_fo(0),
                ouverture_at(0), ouverture_prd(0);
        int lecteurLigne(0);

        // Nom
        QString nom = entree.readLine();

        // Bonus
        QString bonus_string = entree.readLine();
        while (lecteurLigne < bonus_string.size())
        {
            if (bonus_string[lecteurLigne] == '_')
                lecteurLigne++;

            else
            {
                QChar a = bonus_string[lecteurLigne];
                QString bonus = a + bonus_string[lecteurLigne + 1];

                switch (lecteurLigne)
                {
                case 0:
                    ouverture_COU = bonus.toInt();
                    break;
                case 3:
                    ouverture_INT = bonus.toInt();
                    break;
                case 6:
                    ouverture_CHA = bonus.toInt();
                    break;
                case 9:
                    ouverture_AD = bonus.toInt();
                    break;
                case 12:
                    ouverture_FO = bonus.toInt();
                    break;
                case 15:
                    ouverture_AT = bonus.toInt();
                    break;
                case 18:
                    ouverture_PRD = bonus.toInt();
                    break;
                default:
                    QWidget a;
                    QMessageBox::critical(&a, "Erreur", "Impossible d'initialiser les bonus Arme");
                    break;
                }

                lecteurLigne += 2;
            }
        }

        // Malus
        lecteurLigne = 0;
        QString malus_string = entree.readLine();
        while (lecteurLigne < malus_string.size())
        {
            if (malus_string[lecteurLigne] == '_')
                lecteurLigne++;
            else
            {
                QChar a = malus_string[lecteurLigne];
                QString malus = a + malus_string[lecteurLigne + 1];

                switch (lecteurLigne)
                {
                case 0:
                    ouverture_cou = malus.toInt();
                    break;
                case 3:
                    ouverture_int = malus.toInt();
                    break;
                case 6:
                    ouverture_cha = malus.toInt();
                    break;
                case 9:
                    ouverture_ad = malus.toInt();
                    break;
                case 12:
                    ouverture_fo = malus.toInt();
                    break;
                case 15:
                    ouverture_at = malus.toInt();
                    break;
                case 18:
                    ouverture_prd = malus.toInt();
                    break;
                default:
                    QWidget a;
                    QMessageBox::critical(&a, "Erreur", "Impossible d'initialiser les malus Arme");
                    break;
                }

                lecteurLigne += 2;
            }
        }

        // Prix
        int prix = entree.readLine().toInt();

        // Ajout
        Vetement *a = new Vetement(nom,
               ouverture_cou, ouverture_int, ouverture_cha, ouverture_ad, ouverture_fo,
               ouverture_COU, ouverture_INT, ouverture_CHA, ouverture_AD, ouverture_FO);

        vetT.push_back(a);

        ligne = entree.readLine();
    }

    return vetT;
}
QVector<Vetement*> CheckBox::ALL_vets = ouvrirVet();

QVector<Protection*> ouvrirPR()
{
    QVector<Protection*> prT;

    // Protection
    QFile pr("prog-data/pr");

    if (!pr.open(QIODevice::ReadOnly | QIODevice::Text))
        fatalError("Impossible d'ouvrir le fichier contenant les protections !");

    QTextStream entree(&pr);
    entree.setDevice(&pr);

    QString ligne = entree.readLine();

    while (ligne == "~!protection!~")
    {
        int ouverture_COU(0), ouverture_INT(0), ouverture_CHA(0), ouverture_AD(0), ouverture_FO(0),
                ouverture_AT(0), ouverture_PRD(0);
        int ouverture_cou(0), ouverture_int(0), ouverture_cha(0), ouverture_ad(0), ouverture_fo(0),
                ouverture_at(0), ouverture_prd(0);
        int lecteurLigne(0);

        // Nom
        QString nom = entree.readLine();

        // Nombre de d�s
        int nbPr = entree.readLine().toInt();

        // Bonus
        QString bonus_string = entree.readLine();
        while (lecteurLigne < bonus_string.size())
        {
            if (bonus_string[lecteurLigne] == '_')
                lecteurLigne++;

            else
            {
                QChar a = bonus_string[lecteurLigne];
                QString bonus = a + bonus_string[lecteurLigne + 1];

                switch (lecteurLigne)
                {
                case 0:
                    ouverture_COU = bonus.toInt();
                    break;
                case 3:
                    ouverture_INT = bonus.toInt();
                    break;
                case 6:
                    ouverture_CHA = bonus.toInt();
                    break;
                case 9:
                    ouverture_AD = bonus.toInt();
                    break;
                case 12:
                    ouverture_FO = bonus.toInt();
                    break;
                case 15:
                    ouverture_AT = bonus.toInt();
                    break;
                case 18:
                    ouverture_PRD = bonus.toInt();
                    break;
                default:
                    QWidget a;
                    QMessageBox::critical(&a, "Erreur", "Impossible d'initialiser les bonus Arme");
                    break;
                }

                lecteurLigne += 2;
            }
        }

        // Malus
        lecteurLigne = 0;
        QString malus_string = entree.readLine();
        while (lecteurLigne < malus_string.size())
        {
            if (malus_string[lecteurLigne] == '_')
                lecteurLigne++;
            else
            {
                QChar a = malus_string[lecteurLigne];
                QString malus = a + malus_string[lecteurLigne + 1];

                switch (lecteurLigne)
                {
                case 0:
                    ouverture_cou = malus.toInt();
                    break;
                case 3:
                    ouverture_int = malus.toInt();
                    break;
                case 6:
                    ouverture_cha = malus.toInt();
                    break;
                case 9:
                    ouverture_ad = malus.toInt();
                    break;
                case 12:
                    ouverture_fo = malus.toInt();
                    break;
                case 15:
                    ouverture_at = malus.toInt();
                    break;
                case 18:
                    ouverture_prd = malus.toInt();
                    break;
                default:
                    QWidget a;
                    QMessageBox::critical(&a, "Erreur", "Impossible d'initialiser les malus Arme");
                    break;
                }

                lecteurLigne += 2;
            }
        }

        // Prix
        int prix = entree.readLine().toInt();

        // Ajout
        Protection *a = new Protection(nom, nbPr,
               ouverture_cou, ouverture_int, ouverture_cha, ouverture_ad, ouverture_fo,
               ouverture_at, ouverture_prd,
               ouverture_COU, ouverture_INT, ouverture_CHA, ouverture_AD, ouverture_FO,
               ouverture_AT, ouverture_PRD);

        prT.push_back(a);

        ligne = entree.readLine();
    }

    return prT;
}
QVector<Protection*> CheckBox::ALL_pr = ouvrirPR();

QVector<Arme*> ouvrirArmes()
{
    QVector<Arme*> armesT;

    // Armes
    QFile arme("prog-data/armes");

    if (!arme.open(QIODevice::ReadOnly | QIODevice::Text))
        fatalError("Impossible d'ouvrir le fichier contenant les armes !");

    QTextStream entree(&arme);
    entree.setDevice(&arme);

    QString ligne = entree.readLine();

    while (ligne == "~!arme!~")
    {
        int ouverture_COU(0), ouverture_INT(0), ouverture_CHA(0), ouverture_AD(0), ouverture_FO(0),
                ouverture_AT(0), ouverture_PRD(0);
        int ouverture_cou(0), ouverture_int(0), ouverture_cha(0), ouverture_ad(0), ouverture_fo(0),
                ouverture_at(0), ouverture_prd(0);
        int lecteurLigne(0);

        // Nom
        QString ouvertureArme_nom = entree.readLine();

        // Nombre de d�s
        int ouvertureArme_nbDes = entree.readLine().toInt();

        // Nombre de d�g�ts en plus
        int ouvertureArme_degats = entree.readLine().toInt();

        // Bonus
        QString ouvertureArme_bonus_string = entree.readLine();
        while (lecteurLigne < ouvertureArme_bonus_string.size())
        {
            if (ouvertureArme_bonus_string[lecteurLigne] == '_')
                lecteurLigne++;

            else
            {
                QChar a = ouvertureArme_bonus_string[lecteurLigne];
                QString ouvertureArme_bonus = a + ouvertureArme_bonus_string[lecteurLigne + 1];

                switch (lecteurLigne)
                {
                case 0:
                    ouverture_COU = ouvertureArme_bonus.toInt();
                    break;
                case 3:
                    ouverture_INT = ouvertureArme_bonus.toInt();
                    break;
                case 6:
                    ouverture_CHA = ouvertureArme_bonus.toInt();
                    break;
                case 9:
                    ouverture_AD = ouvertureArme_bonus.toInt();
                    break;
                case 12:
                    ouverture_FO = ouvertureArme_bonus.toInt();
                    break;
                case 15:
                    ouverture_AT = ouvertureArme_bonus.toInt();
                    break;
                case 18:
                    ouverture_PRD = ouvertureArme_bonus.toInt();
                    break;
                default:
                    QWidget a;
                    QMessageBox::critical(&a, "Erreur", "Impossible d'initialiser les bonus Arme");
                    break;
                }

                lecteurLigne += 2;
            }
        }

        // Malus
        lecteurLigne = 0;
        QString ouvertureArme_malus_string = entree.readLine();
        while (lecteurLigne < ouvertureArme_malus_string.size())
        {
            if (ouvertureArme_malus_string[lecteurLigne] == '_')
                lecteurLigne++;
            else
            {
                QChar a = ouvertureArme_malus_string[lecteurLigne];
                QString ouvertureArme_malus = a + ouvertureArme_malus_string[lecteurLigne + 1];

                switch (lecteurLigne)
                {
                case 0:
                    ouverture_cou = ouvertureArme_malus.toInt();
                    break;
                case 3:
                    ouverture_int = ouvertureArme_malus.toInt();
                    break;
                case 6:
                    ouverture_cha = ouvertureArme_malus.toInt();
                    break;
                case 9:
                    ouverture_ad = ouvertureArme_malus.toInt();
                    break;
                case 12:
                    ouverture_fo = ouvertureArme_malus.toInt();
                    break;
                case 15:
                    ouverture_at = ouvertureArme_malus.toInt();
                    break;
                case 18:
                    ouverture_prd = ouvertureArme_malus.toInt();
                    break;
                default:
                    QWidget a;
                    QMessageBox::critical(&a, "Erreur", "Impossible d'initialiser les malus Arme");
                    break;
                }

                lecteurLigne += 2;
            }
        }

        // Type d'arme
        int ouvertureArme_type = entree.readLine().toInt();

        // Prix
        int ouvertureArme_prix = entree.readLine().toInt();

        // Ajout
        Arme *a = new Arme(ouvertureArme_nom, ouvertureArme_nbDes, ouvertureArme_degats,
               ouverture_cou, ouverture_int, ouverture_cha, ouverture_ad, ouverture_fo,
               ouverture_at, ouverture_prd,
               ouverture_COU, ouverture_INT, ouverture_CHA, ouverture_AD, ouverture_FO,
               ouverture_AT, ouverture_PRD);
        a->setPrix(ouvertureArme_prix);
        switch (ouvertureArme_type)
        {
        case 0:
            a->setType(Arme::MainNue);
            break;
        case 1:
            a->setType(Arme::Tranchante);
            break;
        case 2:
            a->setType(Arme::Contandante);
            break;
        case 3:
            a->setType(Arme::Projectile);
            break;
        }

        armesT.push_back(a);

        ligne = entree.readLine();
    }

    return armesT;
}
QVector<Arme*> CheckBox::ALL_armes = ouvrirArmes();

QVector<Fleche*> ouvrirFleche()
{
    QVector<Fleche*> flecheT;

    // V�tements
    QFile fleche("prog-data/fleches");

    if (!fleche.open(QIODevice::ReadOnly | QIODevice::Text))
        fatalError("Impossible d'ouvrir le fichier contenant les fl�ches !");

    QTextStream entree(&fleche);

    QString ligne = entree.readLine();

    while (ligne == "~!fleche!~")
    {
        // Nom
        QString nom = entree.readLine();

        // PI en +
        int PI = entree.readLine().toInt();

        // AD en +
        int AD = entree.readLine().toInt();

        // Prix
        int prix = entree.readLine().toInt();

        // Ajout
        Fleche *a = new Fleche(nom, 0, PI, AD);

        flecheT.push_back(a);

        ligne = entree.readLine();
    }

    return flecheT;
}
QVector<Fleche*> CheckBox::ALL_fleches = ouvrirFleche();

QVector<QString> ouvrirEquip()
{
    QVector<QString> equipT;

    // Equipements
    QFile equip("prog-data/equipements");

    if (!equip.open(QIODevice::ReadOnly | QIODevice::Text))
        fatalError("Impossible d'ouvrir le fichier contenant les equipements !");

    QTextStream entree(&equip);
    entree.setDevice(&equip);

    QString ligne = entree.readLine();

    while (ligne == "~!equipement!~")
    {
        // Nom
        QString nom = entree.readLine();

        // Prix
        int prix = entree.readLine().toInt();

        // Ajout
        equipT.push_back(nom);

        ligne = entree.readLine();
    }

    return equipT;
}
QVector<QString> CheckBox::ALL_equipements = ouvrirEquip();
