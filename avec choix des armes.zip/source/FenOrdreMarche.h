#ifndef FENORDREMARCHE_H
    #define FENORDREMARCHE_H

    #include <QtGui>
    #include "Arme.h"

    class FenOrdreMarche : public QWidget
    {
        Q_OBJECT
    public:
        FenOrdreMarche(QStringList const& nomPersos);

        void setNomPersos(QStringList const& nomPersos);

    public slots:
        void select(QModelIndex index);
        void verrouillerBoutons();

        void monter();
        void monter1();
        void descendre1();
        void descendre();

    signals:
        void verrouiller();

    private:
        QMdiArea* affichagePersos;

        QListView *vue;
        QStringList nomPersonnages;
        QStringListModel *modele;

        QPushButton *haut;
        QPushButton *haut1;
        QPushButton *bas;
        QPushButton *bas1;
    };

#endif // FENORDREMARCHE_H
